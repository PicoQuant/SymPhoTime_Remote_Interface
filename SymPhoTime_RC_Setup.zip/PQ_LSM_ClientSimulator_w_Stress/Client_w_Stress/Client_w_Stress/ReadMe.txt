﻿========================================================================
    ANWENDUNG: Client_w_Stress-Projektübersicht
========================================================================

Diese Client_w_Stress-Anwendung wurde vom Anwendungs-Assistenten 
für Sie erstellt.  

Diese Datei bietet eine Übersicht über den Inhalt der einzelnen Dateien, 
aus denen Ihre Client_w_Stress-Anwendung besteht.

Client_w_Stress.vcxproj
    Dies ist die Hauptprojektdatei für VC++-Projekte, die mit dem 
    Anwendungs-Assistenten generiert werden. 
    Sie enthält Informationen über die Version von Visual C++, mit der die
    Datei generiert wurde, sowie über die Plattformen, Konfigurationen und 
    Projektfunktionen, die im Anwendungs-Assistenten ausgewählt wurden.

Client_w_Stress.vcxproj.filters
    Dies ist die Filterdatei für VC++-Projekte, die mithilfe eines 
    Anwendungs-Assistenten erstellt werden. 
    Sie enthält Informationen über die Zuordnung zwischen den Dateien im 
    Projekt und den Filtern. Diese Zuordnung wird in der IDE zur Darstellung 
    der Gruppierung von Dateien mit ähnlichen Erweiterungen unter einem 
    bestimmten Knoten verwendet (z. B. sind CPP-Dateien dem Filter 
    "Quelldateien" zugeordnet).

Client_w_Stress.cpp
    Dies ist die Hauptquelldatei der Anwendung.
    Enthält den Code zum Anzeigen des Formulars.

Client_LSM_SymPhoTime_Dlg.h
    Enthält die Implementierung der Formularklasse und der InitializeComponent()-Funktion.

AssemblyInfo.cpp
    Enthält benutzerdefinierte Attribute zum Ändern von Assemblymetadaten.

/////////////////////////////////////////////////////////////////////////////
Andere Standarddateien:

StdAfx.h, StdAfx.cpp
    Diese Dateien werden verwendet, um eine vorkompilierte Headerdatei
    (PCH-Datei) mit dem Namen "Client_w_Stress.pch und eine 
    vorkompilierte Typendatei mit dem Namen "StdAfx.obj" zu erstellen.

/////////////////////////////////////////////////////////////////////////////
